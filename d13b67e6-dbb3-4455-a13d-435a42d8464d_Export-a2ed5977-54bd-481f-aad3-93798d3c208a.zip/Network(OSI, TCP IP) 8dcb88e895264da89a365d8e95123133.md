# Network(OSI, TCP/IP)

**Mô hình OSI:**

1. **Tầng Vật lý (Physical Layer)**:
    - Chức năng: Đây là tầng thấp nhất trong mô hình OSI và xác định cách dữ liệu được truyền qua các phương tiện truyền thông vật lý như cáp đồng, cáp quang hoặc sóng radio.
    - Ví dụ: Chuẩn Ethernet, cáp mạng Cat5e, cáp quang đơn mód.

1. **Tầng Datalink (Data Link Layer)**:
    - Chức năng: Tầng này quản lý truyền dữ liệu an toàn qua đường truyền vật lý. Nó cung cấp kiểm tra lỗi, định danh thiết bị và quản lý truy cập vào đường truyền.
    - Ví dụ: Giao thức Ethernet, giao thức Wi-Fi (IEEE 802.11), Frame Relay.
2. **Tầng Mạng (Network Layer)**:
    - Chức năng: Tầng này định tuyến dữ liệu thông qua mạng. Nó xác định cách gói dữ liệu sẽ được định tuyến từ nguồn đến đích, dựa trên địa chỉ mạng.
    - Ví dụ: Giao thức IP (Internet Protocol), giao thức ICMP (Internet Control Message Protocol).
3. **Tầng Giao diện (Transport Layer)**:
    - Chức năng: Tầng này đảm bảo dữ liệu được truyền an toàn và đáng tin cậy giữa hai máy tính. Nó cung cấp kiểm tra lỗi, điều khiển luồng dữ liệu và phân đoạn dữ liệu.
    - Ví dụ: Giao thức TCP (Transmission Control Protocol), giao thức UDP (User Datagram Protocol).
4. **Tầng Phiên (Session Layer)**:
    - Chức năng: Tầng này quản lý và duy trì phiên làm việc giữa hai máy tính. Nó đảm bảo rằng phiên hoạt động một cách trơn tru và điều khiển quyền truy cập đồng thời.
    - Ví dụ: Quản lý phiên làm việc, thực hiện đồng bộ hóa.
5. **Tầng Trình bày (Presentation Layer)**:
    - Chức năng: Tầng này thực hiện việc biến đổi và mã hóa dữ liệu để đảm bảo rằng các máy tính trên mạng có thể hiểu và hiển thị thông tin một cách đúng cách.
    - Ví dụ: Mã hóa dữ liệu, nén dữ liệu, định dạng dữ liệu.
6. **Tầng Ứng dụng (Application Layer)**:
    - Chức năng: Tầng này cung cấp giao diện cho người dùng và ứng dụng để truy cập các dịch vụ mạng như trình duyệt web, email và các ứng dụng khác.
    - Ví dụ: Giao thức HTTP (Hypertext Transfer Protocol), giao thức FTP (File Transfer Protocol), giao thức SMTP (Simple Mail Transfer Protocol).

Mô hình OSI giúp các nhà phát triển và quản trị mạng hiểu cách các giao thức mạng tương tác và cung cấp khung làm việc để phát triển và triển khai các hệ thống mạng hiệu quả.

**Mô hình TCP/IP:**

Mô hình TCP/IP (Transmission Control Protocol/Internet Protocol) là một khung làm việc được sử dụng rộng rãi để mô tả cách mạng máy tính hoạt động và cung cấp khung làm việc cho việc truyền tải dữ liệu qua mạng. Mô hình TCP/IP gồm 4 tầng chính, trong đó mỗi tầng đảm nhiệm các chức năng cụ thể:

1. **Tầng Liên kết (Link Layer)**:
    - Chức năng: Tầng này quản lý truyền dữ liệu qua các phương tiện vật lý như cáp mạng, Wi-Fi, hay Bluetooth. Nó đảm bảo dữ liệu được đóng gói thành các khung dữ liệu và định danh thiết bị trên mạng.
    - Ví dụ: Giao thức Ethernet, giao thức Wi-Fi (IEEE 802.11), PPP (Point-to-Point Protocol).
2. **Tầng Mạng (Internet Layer)**:
    - Chức năng: Tầng này đảm bảo định tuyến dữ liệu qua mạng, quyết định cách gói dữ liệu sẽ đi từ nguồn đến đích dựa trên địa chỉ IP.
    - Ví dụ: Giao thức IP (Internet Protocol), giao thức ICMP (Internet Control Message Protocol).
3. **Tầng Giao vận (Transport Layer)**:
    - Chức năng: Tầng này cung cấp điều khiển luồng dữ liệu, kiểm tra lỗi và phân đoạn dữ liệu. Nó đảm bảo dữ liệu được truyền an toàn và đáng tin cậy giữa hai máy tính.
    - Ví dụ: Giao thức TCP (Transmission Control Protocol), giao thức UDP (User Datagram Protocol).
4. **Tầng Ứng dụng (Application Layer)**:
    - Chức năng: Tầng này chứa các ứng dụng và dịch vụ mà người dùng và ứng dụng sử dụng để truy cập mạng. Nó là tầng gần gũi với người dùng cuối và các ứng dụng.
    - Ví dụ: Giao thức HTTP (Hypertext Transfer Protocol), giao thức FTP (File Transfer Protocol), giao thức SMTP (Simple Mail Transfer Protocol).

Mô hình TCP/IP là một mô hình thực tế và phù hợp với cách mạng Internet và mạng máy tính hoạt động. Nó đã được sử dụng rộng rãi trong việc thiết kế, triển khai và quản lý các hệ thống mạng trên toàn thế giới. Các giao thức TCP/IP đóng vai trò quan trọng trong việc kết nối và truyền tải dữ liệu qua Internet và các mạng máy tính.

**So sánh mô hình OSI và TCP/IP:**

![Untitled](Network(OSI,%20TCP%20IP)%208dcb88e895264da89a365d8e95123133/Untitled.png)

Mô hình OSI (Open Systems Interconnection) và mô hình TCP/IP (Transmission Control Protocol/Internet Protocol) là hai khung làm việc quan trọng để hiểu cách các mạng máy tính hoạt động. Dưới đây là một số điểm so sánh giữa chúng:

1. **Số lượng tầng**:
    - OSI: Bao gồm 7 tầng.
    - TCP/IP: Bao gồm 4 tầng.
2. **Phổ biến**:
    - OSI: Tích hợp ít hơn vào thực tế triển khai mạng so với TCP/IP và thường được sử dụng trong việc giảng dạy và tìm hiểu cơ bản về mạng.
    - TCP/IP: Là mô hình được sử dụng rộng rãi và tích hợp chặt chẽ với Internet và hầu hết các mạng thực tế.
3. **Chức năng và mô tả tầng**:
    - OSI: Cung cấp mô tả chi tiết hơn về các tầng và chức năng của chúng, giúp trong việc tìm hiểu cụ thể về cách một tầng hoạt động.
    - TCP/IP: Tích hợp chặt chẽ các tầng, chú trọng vào hiệu suất và thực tế triển khai hơn.
4. **Nguyên tắc hoạt động**:
    - OSI: Thường dùng trong việc tìm hiểu lý thuyết và giảng dạy, ít được triển khai chặt chẽ trong thực tế.
    - TCP/IP: Dựa trên việc triển khai thực tế và là mô hình chuẩn cho Internet.
5. **Sự tương quan**:
    - OSI: Có thể xem là một mô hình tham chiếu, không phụ thuộc vào bất kỳ giao thức cụ thể nào.
    - TCP/IP: Là mô hình thực tế và cũng là giao thức thực hiện công việc truyền tải dữ liệu trên Internet.
6. **Số lớp tương đương**:
    - OSI và TCP/IP có một số lớp tương đương:
        - Tầng Vật lý (Physical Layer) tương đương với Tầng Liên kết (Link Layer).
        - Tầng Mạng (Network Layer) tương đương với Tầng Mạng (Internet Layer).
        - Tầng Giao diện (Transport Layer) tương đương với Tầng Giao vận (Transport Layer).
        - Tầng Ứng dụng (Application Layer) tương đương với Tầng Ứng dụng (Application Layer).

Tóm lại, mô hình OSI là một mô hình tham chiếu với mục tiêu tương đối lý thuyết và giảng dạy, trong khi mô hình TCP/IP là mô hình thực tế được sử dụng rộng rãi và tích hợp chặt chẽ với Internet và mạng máy tính trong thực tế.